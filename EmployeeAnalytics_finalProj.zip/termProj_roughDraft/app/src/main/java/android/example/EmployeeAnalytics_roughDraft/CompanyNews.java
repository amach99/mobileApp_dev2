package android.example.EmployeeAnalytics_roughDraft;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

public class CompanyNews extends AppCompatActivity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_news);

        webView = (WebView) findViewById(R.id.companyNews_page);
        webView.setWebViewClient(new WebViewClient()); // loads web browser within app
        webView.loadUrl("https://www.uml.edu/news/"); // url of website to load
    }

    @Override
    public void onBackPressed() {
        if(webView.canGoBack()) {
            webView.goBack();
        }
        else {
            super.onBackPressed();
        }
    }
}