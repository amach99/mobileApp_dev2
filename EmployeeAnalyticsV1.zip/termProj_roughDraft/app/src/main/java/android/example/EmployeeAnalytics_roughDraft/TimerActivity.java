package android.example.EmployeeAnalytics_roughDraft;

import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class TimerActivity extends AppCompatActivity {

    private static final String LOG_D = TimerActivity.class.getSimpleName();

    int milliSec;
    int sec;
    int min;
    int hours;

    long milliSecTime = 0L;
    long StartTime = 0L;
    long timeBuff = 0L;
    long UpdatedTime = 0L;

    TextView timer;
    Button reset;
    Handler timerHandler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer);

        timer = (TextView) findViewById(R.id.timer);
        timerHandler = new Handler();
        
        final Button startTimer_button = (Button) findViewById(R.id.clockIn_button);
        startTimer_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTimer(v);
            }
        });

        final Button pauseTimer_button = (Button) findViewById(R.id.break_button);
        pauseTimer_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pauseTimer(v);
            }
        });

        final Button resetTimer_button = (Button) findViewById(R.id.clockOut_button);
        resetTimer_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetTimer(v);
            }
        });

        reset = resetTimer_button;
    }

    public Runnable runnable = new Runnable() {

        public void run() {

            milliSecTime = SystemClock.uptimeMillis() - StartTime;

            UpdatedTime = timeBuff + milliSecTime;

            sec = (int) (UpdatedTime / 1000);

            min = sec / 60;

            hours = min / 60;

            sec = sec % 60;

            milliSec = (int) (UpdatedTime % 1000);

            //// TODO: figure out this warning
            timer.setText("" + String.format("%02d", hours) + ":" + String.format("%02d", min) +
                    ":" + String.format("%02d", sec));

            timerHandler.postDelayed(this, 0);
        }
    };

    public void startTimer(View view) {
        StartTime = SystemClock.uptimeMillis(); //

        timerHandler.postDelayed(runnable, 0);

        reset.setEnabled(false); // does not allow user to click the clock out button
    }

    public void pauseTimer(View view) {
        timeBuff += milliSecTime;
        timerHandler.removeCallbacks(runnable);

        reset.setEnabled(true); // allows the user to click the clock out button
    }

    // Reset the timer when the clock out button is clicked.
    public void resetTimer(View view) {

        milliSecTime = 0L;
        StartTime = 0L;
        timeBuff = 0L;
        UpdatedTime = 0L;

        milliSec = 0;
        sec = 0;
        min = 0;
        hours = 0;

        timer.setText(R.string.set_to_zero);
    }

}
