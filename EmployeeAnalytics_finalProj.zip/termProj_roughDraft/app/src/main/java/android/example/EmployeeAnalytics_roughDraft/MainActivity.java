package android.example.EmployeeAnalytics_roughDraft;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;


public class MainActivity extends AppCompatActivity {

    private static final Random RANDOM = new Random();

    private static final String[] QUESTIONS = { // TODO: add more questions
            "How did you sleep last night?",
            "What do you think of weekly meetings on Thursday?",
            "How was your commute?",
            "How do you feel about your team members?",
            "How do you feel about the outcome of the last project?"
    };

    TextView question;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        question = findViewById(R.id.dailyQuestion);

        //button for timer page
        final Button timerPageButton = findViewById(R.id.timerPage_button);
        timerPageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTimerPage(v);
            }
        });

        //button for news page
        final Button newsPageButton = findViewById(R.id.companyNews_button);
        newsPageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewsPage(v);
            }
        });

        //button for settings page
        final Button settingsPageButton = findViewById(R.id.settings_button);
        settingsPageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSettingsPage(v);
            }
        });
    }
    
    public void openTimerPage(View view) {
        Intent timerIntent = new Intent(this, TimerActivity.class);
        startActivity(timerIntent);
    }

    public void openNewsPage(View view) {
        Intent newsIntent = new Intent(this, CompanyNews.class);
        startActivity(newsIntent);
    }

    public void openSettingsPage(View view) {
        Intent settingsIntent = new Intent(this, SettingsActivity.class);
        startActivity(settingsIntent);
    }

    public void displayConfirmationMessage(View view) {
        changeQuestion();
        Toast toast = Toast.makeText(this, "Thank You for your response!", Toast.LENGTH_SHORT);
        toast.show();
    }

    private void changeQuestion(){
        int length = QUESTIONS.length;
        String newQuestion = QUESTIONS[RANDOM.nextInt(length)];
        question.setText(newQuestion);
    }
}
