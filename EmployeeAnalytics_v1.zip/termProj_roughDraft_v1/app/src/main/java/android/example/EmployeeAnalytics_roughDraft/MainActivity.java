package android.example.EmployeeAnalytics_roughDraft;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //button for timer page
        final Button timerPageButton = findViewById(R.id.timerPage_button);
        timerPageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTimerPage(v);
            }
        });

        //button for news page
        final Button newsPageButton = findViewById(R.id.companyNews_button);
        newsPageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNewsPage(v);
            }
        });

        //button for settings page
        final Button settingsPageButton = findViewById(R.id.settings_button);
        settingsPageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSettingsPage(v);
            }
        });
    }
    
    public void openTimerPage(View view) {
        Intent timerIntent = new Intent(this, TimerActivity.class);
        startActivity(timerIntent);
    }

    public void openNewsPage(View view) {
        Intent newsIntent = new Intent(this, CompanyNews.class);
        startActivity(newsIntent);
    }

    public void openSettingsPage(View view) {
        Intent settingsIntent = new Intent(this, SettingsActivity.class);
        startActivity(settingsIntent);
    }

    public void displayConfirmationMessage(View view) {
        Toast toast = Toast.makeText(this, "Thank You for your response!", Toast.LENGTH_SHORT);
        toast.show();
    }



    // TODO: 4/21/21 build displayQ function
    private void displayQuestion(){

    }
}

// how to display log messages in logcat console
//        Log.d("MainActivity", "Hello World");