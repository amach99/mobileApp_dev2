How to Install the Employee Analytics app

1. Unzip the EmployeeAnalyticsV1.zip file
2. Open the unzipped file in Android Studio
