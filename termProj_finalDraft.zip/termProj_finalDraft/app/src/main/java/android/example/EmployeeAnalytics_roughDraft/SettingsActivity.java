package android.example.EmployeeAnalytics_roughDraft;

import android.os.Bundle;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceFragmentCompat;

public class SettingsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.settings, new SettingsFragment())
                .commit();
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }
    }

    public static class SettingsFragment extends PreferenceFragmentCompat {
        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            setPreferencesFromResource(R.xml.root_preferences, rootKey);
        }
    }
}

//  SwitchPreferenceCompat locationSwitch;
//        boolean locSwitchState;
//        String locKey;
//
//        Context context;
//        SharedPreferences preferences;
//        SharedPreferences.Editor editor;
//
//            preferences = PreferenceManager.getDefaultSharedPreferences(this.context);
//                    editor = preferences.edit(); // stores preferences
//
//                    locationSwitch = (SwitchPreferenceCompat) findPreference("Location");
//                    locSwitchState = locationSwitch.isChecked();
//                    locKey = locationSwitch.getKey();
//
//
//                    checkPreferenceState(locationSwitch, locSwitchState, locKey);
//
// private void checkPreferenceState(SwitchPreferenceCompat prefSwitch, Boolean switchState, String key){
//            if (switchState) {
//                prefSwitch.setChecked(true);
//                Toast toast = Toast.makeText(this.context, "Setting changed to True!", Toast.LENGTH_SHORT);
//                toast.show();
//            }
//            else {
//                prefSwitch.setChecked(false);
//                Toast toast = Toast.makeText(this.context, "Setting changed to False!", Toast.LENGTH_SHORT);
//                toast.show();
//            }
//
//            editor.putBoolean(key, switchState);
//            editor.apply();
//
//        }

//  locationSwitch = (SwitchPreferenceCompat) findPreference("Location");
//
//            final SharedPreferences.OnSharedPreferenceChangeListener preferenceChangeListener =
//                    new SharedPreferences.OnSharedPreferenceChangeListener() {
//                        @Override
//                        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
//                            if (key.equals("Location")){
//                                if(locationSwitch != null){
//                                    locationSwitch.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
//                                        @Override
//                                        public boolean onPreferenceChange(Preference preference, Object newValue) {
//                                            preferences.registerOnSharedPreferenceChangeListener();
//                                            return false;
//                                        }
//                                    });
//                                }
//                            }
//                        }
//                    }

//
//        SwitchPreferenceCompat notificationSwitch;
//        SwitchPreferenceCompat nightModeSwitch;
//
//        boolean locationSwitch_state;
//        boolean notificationSwitch_state;
//        boolean nightModeSwitch_state;
//
//        SharedPreferences preferences;

//          preferences = getSharedPreferences("PREFS", 0);
//
//
//            notificationSwitch_state = preferences.getBoolean("Notifications", false);
//            nightModeSwitch_state = preferences.getBoolean("NightMode", false);
//
//
//            notificationSwitch = (SwitchPreferenceCompat) findPreference("Notifications");
//            nightModeSwitch = (SwitchPreferenceCompat) findPreference("NightMode");
//
//
//            notificationSwitch.setChecked(notificationSwitch_state);
//            nightModeSwitch.setChecked(nightModeSwitch_state);
//
//
//            locationSwitch_state = preferences.getBoolean("Location", false);
//            locationSwitch = (SwitchPreferenceCompat) findPreference("Location");
//
//            if(locationSwitch != null) {
//                locationSwitch.setChecked(locationSwitch_state);
//                locationSwitch.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
//                    @Override
//                    public boolean onPreferenceChange(Preference preference, Object newValue) {
//                        final boolean value = (Boolean) newValue;
//                        locationSwitch.setChecked(value);
//                        SharedPreferences.Editor editor = preferences.edit();
//                        editor.putBoolean("Location", locationSwitch_state);
//                        editor.apply();
//
//                        return true;
//                    }
//                });
//
//            }
//
//            notificationSwitch.setOnPreferenceChangeListener(new Preference.OnPreferenceChangeListener() {
//                @Override
//                public boolean onPreferenceChange(Preference preference, Object newValue) {
//                    return false;
//                }
//            });