package android.example.EmployeeAnalytics_roughDraft;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class TimerActivity extends AppCompatActivity {

    private static final String LOG_D = TimerActivity.class.getSimpleName();

    int milliSec;
    int sec;
    int min;
    int hours;

    long milliSecTime = 0L;
    long StartTime = 0L;
    long timeBuff = 0L;
    long UpdatedTime = 0L;

    TextView timer;
    TextView timerText;
    Button reset;
    Button pause;
    Handler timerHandler;
    ProgressBar progressBar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer);

        timer = (TextView) findViewById(R.id.timer);
        timerText = (TextView) findViewById(R.id.timerText);
        timerHandler = new Handler();

        final Button startTimer_button = (Button) findViewById(R.id.clockIn_button);
        startTimer_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startTimer(v);
            }
        });

        final Button pauseTimer_button = (Button) findViewById(R.id.break_button);
        pauseTimer_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pauseTimer(v);
            }
        });

        final Button resetTimer_button = (Button) findViewById(R.id.clockOut_button);
        resetTimer_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetTimer(v);
            }
        });

        reset = resetTimer_button;
        pause = pauseTimer_button;

        progressBar = findViewById(R.id.progressBar);
    }

    public Runnable runnable = new Runnable() {
        public void run() {

            milliSecTime = SystemClock.uptimeMillis() - StartTime;
            UpdatedTime = timeBuff + milliSecTime;

            sec = (int) (UpdatedTime / 1000);
            min = sec / 60;
            hours = min / 60;
            sec = sec % 60;
            milliSec = (int) (UpdatedTime % 1000);

            timer.setText(String.format("%s:%s:%s", String.format("%02d", hours),
                    String.format("%02d", min), String.format("%02d", sec)));

            timerHandler.postDelayed(this, 0);

            // update progress bar
            if (sec > 31)
                progressBar.setIndeterminate(true);
            else
                progressBar.setProgress((int) UpdatedTime);

            changeBackgroundColor();
        }
    };

    // start timer when clock in button is clicked
    public void startTimer(View view) {
        StartTime = SystemClock.uptimeMillis();

        timerHandler.postDelayed(runnable, 0);

        pause.setEnabled(true);
        reset.setEnabled(false);
    }

    // pause timer when lunch break button is clicked
    public void pauseTimer(View view) {
        timeBuff += milliSecTime;
        timerHandler.removeCallbacks(runnable);

        timer.setBackgroundColor(Color.DKGRAY);
        timerText.setTextColor(Color.GRAY);
        timerText.setText(R.string.timer_breakMessage);

        reset.setEnabled(true);
        pause.setEnabled(false);
    }

    // Reset the timer when the clock out button is clicked.
    public void resetTimer(View view) {
        timerHandler.removeCallbacks(runnable);

        milliSecTime = 0L;
        StartTime = 0L;
        timeBuff = 0L;
        UpdatedTime = 0L;

        milliSec = 0;
        sec = 0;
        min = 0;
        hours = 0;

        pause.setEnabled(false);

        timer.setText(R.string.set_to_zero);
        timer.setBackgroundColor(Color.WHITE); // reset color to white
        timer.setTextColor(Color.BLACK);
        timerText.setText(R.string.timer_startingMessage);
        timerText.setTextColor(Color.BLACK);

        progressBar.setIndeterminate(false);
        progressBar.setProgress(0); // reset progress bar
    }

    public void changeBackgroundColor() {

        if (sec > 30) { // overtime
            timer.setBackgroundColor(Color.parseColor("#FF9800"));
            timer.setTextColor(Color.BLACK);
            timerText.setTextColor(Color.BLACK);
            timerText.setText(R.string.timer_overtimeMessage);
        } else if (sec <= 5) { // morning hours
            timer.setBackgroundColor(Color.YELLOW);
            timerText.setText(R.string.timer_morningMessage);
        } else if (sec > 6 && sec < 15) { // afternoon hours
            timer.setBackgroundColor(Color.BLUE);
            timer.setTextColor(Color.WHITE);
            timerText.setTextColor(Color.WHITE);
            timerText.setText(R.string.timer_afternoonMessage);
        } else if (sec > 16 && sec < 30) { // late afternoon - early evening hours
            timer.setBackgroundColor(Color.GREEN);
            timerText.setTextColor(Color.BLACK);
            timerText.setText(R.string.timer_eveningMessage);
        }
    }
}
