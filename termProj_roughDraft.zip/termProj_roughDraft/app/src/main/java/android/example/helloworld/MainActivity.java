package android.example.helloworld;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //button for timer page
        final Button timerPageButton = findViewById(R.id.timerPage_button);
        timerPageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTimerPage(v);
            }
        });
    }

    //todo: fix openTimerPage function
    public void openTimerPage(View view) {
        Intent timerIntent = new Intent(this, TimerActivity.class);
        startActivity(timerIntent);
    }

    private void displayQuestion(){

    }
}

// how to display log messages in logcat console
//        Log.d("MainActivity", "Hello World");