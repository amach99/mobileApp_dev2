
How to Install the Employee Analytics app

1. Unzip the EmployeeAnalyticsV1.zip file
2. Open the unzipped file in Android Studio


Short Description of App:

Attempts to solve low employee engagement and satisfaction levels across most industries.

I chose to create a mobile application to tackle this problem because they are widely accessible
and can be easily implemented into any company. Also an easy to use application is more efficient
at collecting unbiased live data than paper/email surveys, or face to face conversations.


