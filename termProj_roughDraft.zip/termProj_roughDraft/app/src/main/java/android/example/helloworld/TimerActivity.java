package android.example.helloworld;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class TimerActivity extends AppCompatActivity {

    private static final String LOG_D = TimerActivity.class.getSimpleName();;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_timer);

//        final Button backToMain = findViewById(R.id.timerPageBack_button);
//        backToMain.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                openMainPage();
//                Log.d(LOG_D, "Back to main page button clicked");
//            }
//        });

        final Button clockIn_button = findViewById(R.id.clockIn_button);
        clockIn_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                start_timer();
            }
        });

        final Button break_button = findViewById(R.id.break_button);
        break_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pause_timer();
            }
        });

        final Button clockOut_button = findViewById(R.id.clockOut_button);
        clockOut_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pause_timer();
                reset_timer();
            }
        });
    }

    private void start_timer() {
    }

    private void reset_timer() {
    }

    private void pause_timer() {
    }

    private void changeTimerColor() {

    }

    public void openMainPage(View view) {
        Intent backToMain_intent = new Intent(this, MainActivity.class);
        startActivity(backToMain_intent);
    }
}